# nohup accelerate launch train.py > log.txt 2>&1 &
nohup python main.py > log/output.log 2>&1 &